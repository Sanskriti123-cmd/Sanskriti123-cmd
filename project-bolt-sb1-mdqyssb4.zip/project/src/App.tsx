import React, { useState } from 'react';
import { Upload, Stethoscope, AlertCircle, Loader2 } from 'lucide-react';

interface AnalysisResult {
  diagnosis: string;
  confidence: number;
}

function App() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/dicom'];
      if (!validTypes.includes(file.type)) {
        setError('Please upload a valid image file (.jpg, .jpeg, .png, or .dcm)');
        return;
      }
      setSelectedImage(URL.createObjectURL(file));
      setResult(null);
      setError(null);
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      // Simulated API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock response
      setResult({
        diagnosis: Math.random() > 0.5 ? "Malignant" : "Benign",
        confidence: 85 + Math.floor(Math.random() * 13)
      });
    } catch (err) {
      setError("Failed to analyze image. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <Stethoscope className="h-16 w-16 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Medical Image Analysis
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Upload medical images for AI-powered cancer detection analysis. 
            Our advanced algorithms help identify potential abnormalities with high precision.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8">
          <div className="space-y-6">
            {/* Upload Section */}
            <div className="flex flex-col items-center justify-center">
              <label
                htmlFor="image-upload"
                className={`
                  w-full max-w-2xl h-72 flex flex-col items-center justify-center
                  border-2 border-dashed rounded-lg cursor-pointer
                  transition-colors duration-200
                  ${selectedImage ? 'border-blue-400 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}
                `}
              >
                {selectedImage ? (
                  <div className="relative w-full h-full">
                    <img
                      src={selectedImage}
                      alt="Medical scan preview"
                      className="w-full h-full object-contain rounded-lg"
                    />
                  </div>
                ) : (
                  <div className="text-center p-6">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <p className="mt-2 text-sm text-gray-600">
                      Click or drag medical image to upload
                    </p>
                    <p className="mt-1 text-xs text-gray-500">
                      Supported formats: .jpg, .jpeg, .png, .dcm
                    </p>
                  </div>
                )}
                <input
                  id="image-upload"
                  type="file"
                  className="hidden"
                  accept=".jpg,.jpeg,.png,.dcm"
                  onChange={handleImageUpload}
                />
              </label>

              {/* Analysis Button */}
              <button
                onClick={analyzeImage}
                disabled={!selectedImage || isAnalyzing}
                className={`
                  mt-6 px-8 py-3 rounded-lg text-white font-medium
                  transition-colors duration-200
                  ${
                    !selectedImage || isAnalyzing
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }
                `}
              >
                {isAnalyzing ? (
                  <span className="flex items-center">
                    <Loader2 className="animate-spin -ml-1 mr-2 h-5 w-5" />
                    Analyzing Image...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <Stethoscope className="mr-2 h-5 w-5" />
                    Analyze Image
                  </span>
                )}
              </button>
            </div>

            {/* Error Message */}
            {error && (
              <div className="mt-4 p-4 bg-red-50 rounded-lg flex items-start">
                <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 mr-2" />
                <p className="text-red-600">{error}</p>
              </div>
            )}

            {/* Results Section */}
            {result && (
              <div className="mt-6 p-6 bg-gray-50 rounded-lg border border-gray-200">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  Analysis Results
                </h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Diagnosis:</span>
                    <span className={`font-medium ${
                      result.diagnosis === 'Malignant' ? 'text-red-600' : 'text-green-600'
                    }`}>
                      {result.diagnosis}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Confidence:</span>
                    <span className="font-medium text-gray-900">
                      {result.confidence}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div
                      className={`h-2.5 rounded-full ${
                        result.diagnosis === 'Malignant' ? 'bg-red-600' : 'bg-green-600'
                      }`}
                      style={{ width: `${result.confidence}%` }}
                    ></div>
                  </div>
                  
                  <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-800">
                      <strong>Important Notice:</strong> This analysis is provided as a screening tool only. 
                      Please consult with a qualified medical professional for proper diagnosis and treatment. 
                      AI results should always be verified by a healthcare provider.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;